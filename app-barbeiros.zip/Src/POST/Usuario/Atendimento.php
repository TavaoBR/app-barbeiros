<?php 

namespace Src\POST\Usuario;



class Atendimento {

}