<?php 

namespace Src\Database\Model;

class HorarioAtendimento extends Models {

    protected string $table = 'horariosatendimentobarbeiro';
    
    
}