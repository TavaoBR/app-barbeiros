<?php

namespace Src\Database\Model;

class AcessoBarbeiro extends Models {

    protected string $table = 'soliticaracessobarbeiro';

}