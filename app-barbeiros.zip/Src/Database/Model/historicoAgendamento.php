<?php 

namespace Src\Database\Model;

class historicoAgendamento extends Models
{
    protected string $table = 'historicoAgendamento';
}