<?php 

namespace Src\Database\Model;

class ServicoBarbeiro extends Models{

    protected string $table = 'servicosbarbeiro';

}