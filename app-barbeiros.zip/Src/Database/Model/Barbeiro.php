<?php 

namespace Src\Database\Model;

class Barbeiro extends Models{
    
    protected string $table = 'perfilbarbeiro';
}