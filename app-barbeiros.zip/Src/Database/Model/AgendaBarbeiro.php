<?php 

namespace Src\Database\Model;

class AgendaBarbeiro extends Models 
{

    protected string $table = 'agendabarbeiro';

}