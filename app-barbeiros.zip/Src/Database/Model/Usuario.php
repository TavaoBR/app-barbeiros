<?php 

namespace Src\Database\Model;

class Usuario extends Models{
    
    protected string $table = 'usuario';
    
     
}