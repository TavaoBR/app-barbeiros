<?=$this->layout("error", ['title' => $title])?>

<div class="page-404">
    <div class="outer">
        <div class="middle">
            <div class="inner">
                <!--BEGIN CONTENT-->
                <div class="inner-circle"><i class="fa fa-cogs"></i><span>500</span></div>
                <span class="inner-status">Opps! Erro Interno de Servidor</span>
                <span class="inner-detail"><a href="javascript:history.go(-1);" class="btn btn-custom btn-primary">Clique aqui para sair da pagina</a></span>
                <!--END CONTENT-->
            </div>
        </div>
    </div>
</div>